package com.example.framenttest;

import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.framenttest.fragment.BottomFragment;
import com.example.framenttest.fragment.TopFragment;
import com.example.framenttest.utils.RadioStatus;

public class MainActivity extends AppCompatActivity {

    private final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.e(TAG, "onCreate: " );
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioStatus.setCurrentModeStatus(RadioStatus.ModeStatus.LOCAL);

        TopFragment topFragment = new TopFragment();
        BottomFragment bottomFragment = new BottomFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction()
                .add(R.id.fl_top,topFragment)
                .add(R.id.fl_below,bottomFragment)
                .commit();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
