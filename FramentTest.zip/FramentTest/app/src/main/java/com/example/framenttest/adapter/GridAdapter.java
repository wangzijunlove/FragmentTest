package com.example.framenttest.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.framenttest.R;

import java.util.List;

/**
 * Created by archermind on 11/27/19.
 * Wzj
 * content
 */
public class GridAdapter extends RecyclerView.Adapter<GridAdapter.MyViewHold> {

    private LayoutInflater layoutInflater;
    private List<String> list;//数据源
    private Context context;
    private OnItemClickListener listener;//点击事件的接口

    public GridAdapter(Context context, List<String> list){
        layoutInflater = LayoutInflater.from( context );
        this.list = list;
        this.context = context;
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
        void onCancelCollection(int position);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @Override
    public GridAdapter.MyViewHold onCreateViewHolder( ViewGroup viewGroup, int i) {
        return new MyViewHold(layoutInflater.inflate(R.layout.item_local_collection, viewGroup, false ));
    }

    @Override
    public void onBindViewHolder(final GridAdapter.MyViewHold myViewHold, int i) {
        myViewHold.name.setText(list.get(i));
        myViewHold.imageView.setBackgroundResource(R.mipmap.a2);

        //取消收藏
        myViewHold.name.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n = myViewHold.getLayoutPosition();
                listener.onCancelCollection(n);
            }
        } );

        //点击播放事件
        myViewHold.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int n = myViewHold.getLayoutPosition();
                listener.onItemClick(n);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class MyViewHold extends RecyclerView.ViewHolder{
        TextView name;
        ImageView imageView;
        public MyViewHold( View itemView) {
            super(itemView);
            name=(TextView)itemView.findViewById(R.id.item_tv);
            imageView = itemView.findViewById(R.id.iv);
        }
    }
}
