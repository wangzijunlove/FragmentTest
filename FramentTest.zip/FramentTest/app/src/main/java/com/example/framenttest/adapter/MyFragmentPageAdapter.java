package com.example.framenttest.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.Log;
import android.util.SparseArray;
import android.view.ViewGroup;

import java.util.List;

/**
 * Created by archermind on 11/27/19.
 * Wzj
 * content
 */
public class MyFragmentPageAdapter extends FragmentPagerAdapter {

    public String TAG = "FragmentAdpter";
    List<Fragment> mFragments;
    FragmentManager manager;
    SparseArray<String> tags = new SparseArray<>();

    public void setList(List<Fragment> list) {
        this.mFragments = list;
        notifyDataSetChanged();
    }

    public MyFragmentPageAdapter(FragmentManager fm,List<Fragment> list) {
        super(fm);
        mFragments = list;
        manager = fm;
        Log.d(TAG, "FragmentAdpter: ");
    }

    @Override
    public Fragment getItem(int i) {
        return mFragments.get(i);
    }

    @Override
    public int getCount() {
        return mFragments.size();
    }

    @Override
    public int getItemPosition(Object object) {
        Fragment fragment = (Fragment) object;
        //如果Item对应的Tag存在，则不进行刷新
        if (tags.indexOfValue(fragment.getTag()) > -1) {
            return super.getItemPosition(object);
        }
        return POSITION_NONE;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        //得到缓存的fragment
        Fragment fragment = (Fragment) super.instantiateItem(container, position);
        String tag = fragment.getTag();
        //保存每个Fragment的Tag
        tags.put(position, tag);
        return fragment;
    }


    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    public List<Fragment> getFragments(){
        Log.d(TAG, "getFragments: "+manager.getFragments().size());
        return manager.getFragments();
    }

    //刷新指定位置的Fragment
    public void notifyFragmentByPosition(int position) {
        Log.d(TAG, "notifyFragmentByPosition: ");
        tags.removeAt(position);
        notifyDataSetChanged();
    }
}
