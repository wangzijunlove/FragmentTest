package com.example.framenttest.base;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by archermind on 11/27/19.
 * Wzj
 * content
 */
public abstract class BaseFragment extends Fragment {

    private View rootView;
    private final String TAG = "BaseFragment";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        Log.e(TAG, "onCreateView: " );
        if(rootView == null){
            rootView = CreateView(inflater,container,savedInstanceState);
            initView(rootView);
        }
        return rootView;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        Log.e(TAG, "setUserVisibleHint: " );
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            onVisible();
        } else {
            onInVisible();
        }
    }

    protected void onVisible() {
        Log.e(TAG, "onVisible: " );
        onVisibleRefresh();
    }

    protected void onInVisible() {
        Log.e(TAG, "onInVisible: " );
        onInVisibleRefresh();
    }

    protected abstract View CreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState);
    protected abstract void initView(View root);
    protected abstract void onVisibleRefresh();
    protected abstract void onInVisibleRefresh();

}
