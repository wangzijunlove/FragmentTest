package com.example.framenttest.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.framenttest.R;
import com.example.framenttest.adapter.MyFragmentPageAdapter;
import com.example.framenttest.base.BaseFragment;
import com.example.framenttest.utils.RadioStatus;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by archermind on 11/27/19.
 * Wzj
 * content
 */
public class BottomFragment extends BaseFragment implements View.OnClickListener,TopFragment.loadBottomFragment {

    public final String TAG = "BottomFragment";
    private ViewPager viewPager;
    private static MyFragmentPageAdapter adapter;
    private static List<Fragment> listData = new ArrayList<>();
    private TextView localFM,localAM,localCollection,networkCommend,networkSort,networkRadio,networkHistroy,networkCollection;
    private LinearLayout local,network;

    protected  FmFragment fmFragment;
    protected  AmFragment amFragment;
    protected  LoacalCollectionFragment loacalCollectionFragment;
    protected  NetworkCollectionFragment networkCollectionFragment;
    protected  NetworkCommendFragment networkCommendFragment;
    protected  NetworkSortFragment networkSortFragment;
    protected  NetworkRadioFragment networkRadioFragment;
    protected  NetworkHistoryFragment networkHistoryFragment;

    @Override
    protected View CreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.bottom_fragment,container,false);
        local = view.findViewById(R.id.layout_local);
        network = view.findViewById(R.id.layout_network);
        viewPager = view.findViewById(R.id.viewPager_content);
        TopFragment.setLoadBottomFragmentListen(this);

        //初始化操作
        listData.clear();
        adapter = new MyFragmentPageAdapter(getChildFragmentManager(),listData);
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(8);

        if(RadioStatus.isInLocal()){
            local.setVisibility(View.VISIBLE);
            network.setVisibility(View.INVISIBLE);
            setTabSelection(fmFragment,"FmFragment" );
        }else if(RadioStatus.isInNetwork()){
            local.setVisibility(View.INVISIBLE);
            network.setVisibility(View.VISIBLE);
            setTabSelection(networkCommendFragment, "NetworkCommendFragment");
        }else {
            local.setVisibility(View.VISIBLE);
            network.setVisibility(View.INVISIBLE);
            setTabSelection(fmFragment,"FmFragment" );
        }
        return view;
    }

    /**
     * 动态加载Fragment
     * @param fragment
     * @param fragmentName
     */
    private void setTabSelection(Fragment fragment, String fragmentName) {
        boolean fragmentCreate = false;
        if(fragmentName.equals("FmFragment")){
            if (!listData.contains(fmFragment)) {
                fmFragment = new FmFragment();
                listData.add(fmFragment);
                adapter.setList(listData);
                fragmentCreate = true;
            }
        }else if(fragmentName.equals("AmFragment")){
            if (!listData.contains(amFragment)) {
                amFragment = new AmFragment();
                listData.add(amFragment);
                adapter.setList(listData);
                fragmentCreate = true;
            }
        }else if(fragmentName.equals("LoacalCollectionFragment")){
            if (!listData.contains(loacalCollectionFragment)) {
                loacalCollectionFragment = new LoacalCollectionFragment();
                listData.add(loacalCollectionFragment);
                adapter.setList(listData);
                fragmentCreate = true;
            }
        }else if(fragmentName.equals("NetworkCommendFragment")){
            if (!listData.contains(networkCommendFragment)) {
                networkCommendFragment = new NetworkCommendFragment();
                listData.add(networkCommendFragment);
                adapter.setList(listData);
                fragmentCreate = true;
            }
        }else if(fragmentName.equals("NetworkSortFragment")){
            if (!listData.contains(networkSortFragment)) {
                networkSortFragment = new NetworkSortFragment();
                listData.add(networkSortFragment);
                adapter.setList(listData);
                fragmentCreate = true;
            }
        }else if(fragmentName.equals("NetworkRadioFragment")){
            if (!listData.contains(networkRadioFragment)) {
                networkRadioFragment = new NetworkRadioFragment();
                listData.add(networkRadioFragment);
                adapter.setList(listData);
                fragmentCreate = true;
            }
        }else if(fragmentName.equals("NetworkCollectionFragment")){
            if (!listData.contains(networkCollectionFragment)) {
                networkCollectionFragment = new NetworkCollectionFragment();
                listData.add(networkCollectionFragment);
                adapter.setList(listData);
                fragmentCreate = true;
            }
        }else if(fragmentName.equals("NetworkHistoryFragment")){
            if (!listData.contains(networkHistoryFragment)) {
                networkHistoryFragment = new NetworkHistoryFragment();
                listData.add(networkHistoryFragment);
                adapter.setList(listData);
                fragmentCreate = true;
            }
        }
        if (fragmentCreate) {
            viewPager.setCurrentItem((listData.size() - 1), false);
        } else {
            int index = listData.indexOf(fragment);
            viewPager.setCurrentItem(index, false);
            Log.d(TAG, "setTabSelection: index" + index + " " + fragment);
        }
    }

    @Override
    protected void initView(View viewRoot) {
        localFM = viewRoot.findViewById(R.id.tv_local_FM);
        localFM.setOnClickListener(this);

        localAM = viewRoot.findViewById(R.id.tv_local_AM);
        localAM.setOnClickListener(this);

        localCollection = viewRoot.findViewById(R.id.tv_local_collection);
        localCollection.setOnClickListener(this);

        networkCommend = viewRoot.findViewById(R.id.tv_network_command);
        networkCommend.setOnClickListener(this);

        networkSort = viewRoot.findViewById(R.id.tv_network_sort);
        networkSort.setOnClickListener(this);

        networkRadio = viewRoot.findViewById(R.id.tv_network_radio);
        networkRadio.setOnClickListener(this);

        networkHistroy = viewRoot.findViewById(R.id.tv_network_history);
        networkHistroy.setOnClickListener(this);

        networkCollection = viewRoot.findViewById(R.id.tv_network_collection);
        networkCollection.setOnClickListener(this);
    }


    @Override
    protected void onVisibleRefresh() {

    }

    @Override
    protected void onInVisibleRefresh() {

    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.tv_local_FM:
                setTabSelection(fmFragment,"FmFragment" );
                break;
            case R.id.tv_local_AM:
                setTabSelection(amFragment,"AmFragment" );
                break;
            case R.id.tv_local_collection:
                setTabSelection(loacalCollectionFragment,"LoacalCollectionFragment" );
                break;
            case R.id.tv_network_command:
                setTabSelection(networkCommendFragment,"NetworkCommendFragment" );
                break;
            case R.id.tv_network_sort:
                setTabSelection(networkSortFragment,"NetworkSortFragment" );
                break;
            case R.id.tv_network_radio:
                setTabSelection(networkRadioFragment,"NetworkRadioFragment" );
                break;
            case R.id.tv_network_collection:
                setTabSelection(networkCollectionFragment,"NetworkCollectionFragment" );
                break;
            case R.id.tv_network_history:
                setTabSelection(networkHistoryFragment,"NetworkHistoryFragment" );
                break;

        }
    }

    @Override
    public void loadFragment() {
        if(RadioStatus.isInLocal()){
            local.setVisibility(View.VISIBLE);
            network.setVisibility(View.INVISIBLE);
            setTabSelection(fmFragment,"FmFragment" );
        }else if(RadioStatus.isInNetwork()){
            local.setVisibility(View.INVISIBLE);
            network.setVisibility(View.VISIBLE);
            setTabSelection(networkCommendFragment, "NetworkCommendFragment");
        }
    }
}
