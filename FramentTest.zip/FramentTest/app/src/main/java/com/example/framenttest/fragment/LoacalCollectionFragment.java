package com.example.framenttest.fragment;

import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.framenttest.R;
import com.example.framenttest.adapter.GridAdapter;
import com.example.framenttest.base.BaseFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by archermind on 11/27/19.
 * Wzj
 * content
 */
public class LoacalCollectionFragment extends BaseFragment{
    private List<String> dataList = new ArrayList<>();
    private List<String> dataLists = new ArrayList<>();
    private RecyclerView fm_rv,am_rv;

    @Override
    protected View CreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_local_collection, container, false);
        return view;
    }

    @Override
    protected void initView(View root) {
        fm_rv = (RecyclerView) root.findViewById(R.id.fm_rv);
        am_rv = (RecyclerView) root.findViewById(R.id.am_rv);
        initAdapter();
    }

    private void initAdapter(){
        GridAdapter adapter = new GridAdapter(getContext(), dataList);
        GridAdapter adapters = new GridAdapter(getContext(), dataLists);
        adapter.setOnItemClickListener(new GridAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Toast.makeText(getContext(),"fm开始播放！",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelCollection(int position) {
                Toast.makeText(getContext(),"收藏Fm！",Toast.LENGTH_LONG).show();
            }
        });
        adapters.setOnItemClickListener(new GridAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Toast.makeText(getContext(),"am开始播放！",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onCancelCollection(int position) {
                Toast.makeText(getContext(),"收藏Am！",Toast.LENGTH_LONG).show();
            }
        });
        fm_rv.setAdapter(adapter);
        am_rv.setAdapter(adapters);
        final GridLayoutManager layoutManagerFm = new GridLayoutManager(getContext(), 4, LinearLayoutManager.VERTICAL, false);
        final GridLayoutManager layoutManagerAm = new GridLayoutManager(getContext(), 4, LinearLayoutManager.VERTICAL, false);
        fm_rv.setLayoutManager(layoutManagerFm);
        am_rv.setLayoutManager(layoutManagerAm);
    }

    @Override
    protected void onVisibleRefresh() {
        getData();

    }

    @Override
    protected void onInVisibleRefresh() {

    }

    private void getData() {
        dataList.add("第一个");
        dataList.add("第二个");
        dataList.add("第三个");
        dataList.add("第四个");
        dataList.add("第五个");
        dataList.add("第六个");
        dataList.add("第七个");

        //做一些假数据
        dataLists.add("第一个");
        dataLists.add("第二个");
        dataLists.add("第三个");
        dataLists.add("第四个");
        dataLists.add("第五个");
        dataLists.add("第六个");
        dataLists.add("第七个");
        dataLists.add("第八个");
        dataLists.add("第九个");
        dataLists.add("第十个");
    }

}
