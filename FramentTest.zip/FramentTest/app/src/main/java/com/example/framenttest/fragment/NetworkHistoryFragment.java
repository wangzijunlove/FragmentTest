package com.example.framenttest.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.framenttest.R;
import com.example.framenttest.base.BaseFragment;

/**
 * Created by archermind on 11/27/19.
 * Wzj
 * content
 */
public class NetworkHistoryFragment extends BaseFragment {
    @Override
    protected View CreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_network_history,container,false);
        return view;
    }

    @Override
    protected void initView(View root) {

    }

    @Override
    protected void onVisibleRefresh() {

    }

    @Override
    protected void onInVisibleRefresh() {

    }
}
