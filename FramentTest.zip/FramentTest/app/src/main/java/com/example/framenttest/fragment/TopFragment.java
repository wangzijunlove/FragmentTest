package com.example.framenttest.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.framenttest.R;
import com.example.framenttest.adapter.MyFragmentPageAdapter;
import com.example.framenttest.base.BaseFragment;
import com.example.framenttest.utils.RadioStatus;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by archermind on 11/27/19.
 * Wzj
 * content
 */
public class TopFragment extends BaseFragment {

    private ViewPager topViewPage;
    private MyFragmentPageAdapter myFragmentPageAdapter;
    List<Fragment> fragmentList = new ArrayList<>();
    private LocalRadioFragment fragmentLocal;
    private XmlyRadioFragment fragmentNetworkXMLY;
    private KlRadioFragment fragmentKL;
    private TextView local_play,networkXMLY_play,networkKL_paly;
    public final String TAG = "TopFragment";

    @Override
    protected View CreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_top,container,false);
        return view;
    }

    @Override
    protected void initView(View root) {
        topViewPage = root.findViewById(R.id.vp_top);
        local_play = root.findViewById(R.id.tv_top_local);
        networkKL_paly = root.findViewById(R.id.tv_top_kl);
        networkXMLY_play = root.findViewById(R.id.tv_top_xmly);
        //将Fragment new出来添加到数组
        fragmentList.clear();
        fragmentLocal = new LocalRadioFragment();
        fragmentNetworkXMLY = new XmlyRadioFragment();
        fragmentKL = new KlRadioFragment();
        fragmentList.add(fragmentLocal);
        fragmentList.add(fragmentNetworkXMLY);
        fragmentList.add(fragmentKL);

        myFragmentPageAdapter = new MyFragmentPageAdapter(getChildFragmentManager(),fragmentList);
        myFragmentPageAdapter.setList(fragmentList);
        topViewPage.setAdapter(myFragmentPageAdapter);
        topViewPage.setOffscreenPageLimit(3);


        if(RadioStatus.isInNetwork()){
            setTopFragmentByPosition(1);
        }else {
            setTopFragmentByPosition(0);
        }
        local_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioStatus.setCurrentModeStatus(RadioStatus.ModeStatus.LOCAL);
                setTopFragmentByPosition(0);
                if(loadBottomFragmentListen != null){
                    loadBottomFragmentListen.loadFragment();
                }
            }
        });

        networkKL_paly.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioStatus.setCurrentModeStatus(RadioStatus.ModeStatus.NETWORK);
                setTopFragmentByPosition(2);
                if(loadBottomFragmentListen != null){
                    loadBottomFragmentListen.loadFragment();
                }
            }
        });

        networkXMLY_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioStatus.setCurrentModeStatus(RadioStatus.ModeStatus.NETWORK);
                setTopFragmentByPosition(1);
                if(loadBottomFragmentListen != null){
                    loadBottomFragmentListen.loadFragment();
                }
            }
        });

    }

    private void setTopFragmentByPosition(int position) {
        if(position == 0){
            topViewPage.setCurrentItem(0);
        }else if(position == 1){
            topViewPage.setCurrentItem(1);
        }else if(position == 2){
            topViewPage.setCurrentItem(2);
        }
    }

    @Override
    protected void onVisibleRefresh() {

    }

    @Override
    protected void onInVisibleRefresh() {

    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public static loadBottomFragment loadBottomFragmentListen;

    public static void setLoadBottomFragmentListen(loadBottomFragment listen) {
        loadBottomFragmentListen = listen;
    }


    public interface loadBottomFragment{
        void loadFragment();
    }

}
