package com.example.framenttest.utils;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

public class EasyViewPager extends ViewPager {


    private boolean mIsCanScroll;

    public EasyViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public EasyViewPager(Context context) {
        super(context);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        //禁止的话返回false
        if (!mIsCanScroll) {
            return false;
        }
        return super.onInterceptTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        //禁止的话返回false
        if (!mIsCanScroll) {
            return false;
        }
        return super.onTouchEvent(ev);
    }

    /**
     * @param isCanScroll 是否可以滑动切花，true可以，false禁止
     */
    public void setCanScroll(boolean isCanScroll) {
        this.mIsCanScroll = isCanScroll;
    }

    /**
     * 重新setCurrentItem一个参数的函数，调用两个参数的函数
     *
     * @param item
     */
    @Override
    public void setCurrentItem(int item) {
        super.setCurrentItem(item, mIsCanScroll);//传入false禁止切换动画
    }
}