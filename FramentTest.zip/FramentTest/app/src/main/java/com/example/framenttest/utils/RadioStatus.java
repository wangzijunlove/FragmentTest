package com.example.framenttest.utils;


public class RadioStatus {
    public enum ModeStatus {LOCAL, NETWORK, UNINITIALIZED}

    public enum NetworkMode {NETWORKRADIO_KL, NETWORKRADIO_XMLY, UNKNOWN}

    private static NetworkMode mDevicesMode;
    private static ModeStatus mModeStatus;

    public enum Type {PGC, ALBUM, BROADCAST}

    public enum Status {playing, noprogram}

    private static Type currentType;
    private static Status currentStatus;
    public static boolean isPausedByChangerData = false;
    public static boolean isPausedByChangerDataXMLY;
    public static int mCurrentStepFm = 0,mCurrentStepAm = 0;
    public static boolean flagIsSoundStart = false;



    public static NetworkMode getCurrentNetworkMode() {
        if (mDevicesMode == null) {
            return null;
        }
        return mDevicesMode;
    }

    public static boolean isInKLRadio() {
        return mDevicesMode == NetworkMode.NETWORKRADIO_KL;
    }

    public static boolean isInXMLYRadio() {
        return mDevicesMode == NetworkMode.NETWORKRADIO_XMLY;
    }

    public static void setCurrentNetworkMode(NetworkMode targetMode) {
        mDevicesMode = targetMode;
    }

    public static void setCurrentStatus(Status status) {
        currentStatus = status;
    }

    public static Status getCurrentStatus() {
        return currentStatus;
    }

    public static void setCurrentType(Type targetType) {
        currentType = targetType;
    }

    public static Type getCurrentType() {
        return currentType;
    }

    public static ModeStatus getCurrentModeStatus() {
        if (mModeStatus == null) {
            return null;
        }
        return mModeStatus;
    }

    public static int getmCurrentStepFm() {
        return mCurrentStepFm;
    }

    public static int getmCurrentStepAm() {
        return mCurrentStepAm;
    }

    public static void setmCurrentStepAm(int mCurrentStepAm) {
        RadioStatus.mCurrentStepAm = mCurrentStepAm;
    }

    public static void setmCurrentStepFm(int mCurrentStepFm) {
        RadioStatus.mCurrentStepFm = mCurrentStepFm;

    }

    public static boolean isInLocal() {
        return mModeStatus == ModeStatus.LOCAL;
    }

    public static boolean isInNetwork() {
        return mModeStatus == ModeStatus.NETWORK;
    }

    public static void setCurrentModeStatus(ModeStatus targetMode) {
        mModeStatus = targetMode;
    }

}
